# MediAgents: AI-Powered Medical Triage & Clinical Intelligence

MediAgents (ClinicAI) is a high-performance, hybrid medical triage system powered by **TinyLlama-1.1B**. It combines deterministic medical rule engines with probabilistic LLM reasoning to provide safe, fast, and explainable clinical decisions.

---

## 🚀 Core Features

- **Hybrid Triage Engine**: Merges a hard-coded Medical Rule Engine (safety layer) with TinyLlama-1.1B reasoning.
- **Local Inference**: Runs entirely on your local hardware using PyTorch (MPS/CUDA) or a custom **Pure NumPy** implementation.
- **Explainable AI**: Generates clinical reasoning narratives and identifies "attention signals" from the model's hidden states.
- **Safety First**: 
    - Deterministic drug interaction checking.
    - ICD-10 code resolution.
    - Automatic escalation for high-risk age groups and comorbidities.
- **Hardware Optimized**: Automatic detection for Apple Silicon (MPS) and NVIDIA GPUs (CUDA).

---

## 🏗 Project Architecture

```text
MediAgents/
├── agent_01_triage/        # Core triage business logic
│   ├── triage_engine.py    # Deterministic rule engine
│   └── demo.py             # Basic interactive demo
├── llm/                    # TinyLlama Deep Integration
│   ├── tinyllama_engine.py # PURE NUMPY inference (Custom Architecture)
│   ├── triage_engine_llm.py# Hybrid Rule + LLM Orchestrator
│   └── demo_llm.py         # Advanced TinyLlama demo
├── llm_engine.py           # HuggingFace/Transformers wrapper
├── test_generation.py      # Standalone LLM text generation tester
└── model_cache/            # Local storage for model weights
```

---

## 🛠 Installation & Setup

### 1. Requirements
- Python 3.9+
- 8GB+ RAM Recommended
- Disk Space: ~2.5GB for TinyLlama weights

### 2. Dependencies
```bash
pip install torch transformers numpy
```

### 3. Hardware Optimization (HP Victus / NVIDIA Laptops)
To enable fast inference on NVIDIA GPUs, ensure you have the CUDA version of PyTorch:
```bash
pip uninstall torch
pip install torch --index-url https://download.pytorch.org/whl/cu121
```

> **⚡ HP Victus Tip:** To get maximum speed, open the **OMEN Gaming Hub**, go to **Optimizer/Performance**, and ensure your laptop is set to **"Performance Mode"** and the **"Discrete GPU"** is active (not Eco mode). Ensure the laptop is **plugged into power** for full GPU performance.

---

## 🏃 Usage

### 🏥 Full Medical Triage Demo
Run the hybrid triage engine with pre-defined clinical scenarios:
```bash
python llm/demo_llm.py
```
For interactive mode:
```bash
python llm/demo_llm.py --interactive
```

### 🤖 Standard Text Generation
Test the raw TinyLlama model for general conversation:
```bash
python test_generation.py
```

---

## 🧠 The TinyLlama Engine

This project features two ways to run the LLM:
1.  **Standard Mode**: Uses `transformers` and `torch` (best for GPU/MPS speed).
2.  **Pure NumPy Mode** (`llm/tinyllama_engine.py`): A custom implementation of the Llama architecture using only NumPy. This is used for "Fast Mode" and education on LLM internals.

### Decision Fusion Algorithm
The system uses a **Safety-First Consensus** model:
1.  **Rule Engine** checks for "Red Flag" patterns (Emergency).
2.  **LLM** analyzes the nuanced description.
3.  **Consensus**: If the LLM is highly confident (>80%), it leads. If there is a disagreement, the system defaults to the **most urgent** tier.

---

## ⚠️ Disclaimer

**This is a prototype for educational and demonstration purposes only.** 
MediAgents is not a medical device and its outputs should not be used for actual medical diagnosis or treatment decisions. Always consult a qualified healthcare professional for medical emergencies.

---
*Created by Antigravity AI for Advancing Agentic Coding.*
